# pot_detection > Color 2024-12-18 1-54pm
https://universe.roboflow.com/toolbox-and-equipment-tracker/pot_detection-pucaa-xqko4

Provided by a Roboflow user
License: CC BY 4.0

